import { createContext, useCallback, useContext, useEffect, useMemo, useReducer, useState } from "react";
import { auth, firebaseReady } from "../firebase";
import { onAuthStateChanged } from "firebase/auth";
import { initialState } from "../data";
import { loadStoredState, saveLocalState } from "../services/appStateRepository";
import { generateOrderCode } from "../services/orderCode";
import type { AppState, BankPlacement, Member, Order, Product, StaffAdmin, Transaction } from "../types";
import { subscribeToMember } from "../services/membersService";
import { getAuthContext } from "../services/authService";

type Action =
  | { type: "hydrate"; payload: AppState }
  | { type: "createTransaction"; payload: Pick<Transaction, "member" | "type" | "amount"> }
  | { type: "addTransaction"; payload: Transaction }
  | { type: "updateTransaction"; payload: { id: string; status: "approved" | "rejected" } }
  | { type: "updateMember"; payload: Member }
  | { type: "createOrder"; payload: { member: string; productId?: string } }
  | { type: "addOrder"; payload: Order }
  | { type: "updateOrder"; payload: Order }
  | { type: "replaceMemberOrders"; payload: { memberId: string; orders: Order[] } }
  | { type: "completeOrder"; payload: { orderId: string } }
  | { type: "completeOrderWithMember"; payload: { order: Order; member: Member } }
  | { type: "addProduct"; payload: Omit<Product, "id"> & { id?: string } }
  | { type: "updateProduct"; payload: Product }
  | { type: "deleteProduct"; payload: { id: string } }
  | { type: "addBank"; payload: Omit<BankPlacement, "id"> & { id?: string } }
  | { type: "updateBank"; payload: BankPlacement }
  | { type: "deleteBank"; payload: { id: string } }
  | { type: "addAdmin"; payload: StaffAdmin }
  | { type: "updateAdmin"; payload: StaffAdmin }
  | { type: "deleteAdmin"; payload: { id: string } }
  | { type: "updateAccount"; payload: AppState["account"] };

interface AppStoreValue {
  state: AppState;
  ready: boolean;
  persistence: "firebase" | "local";
  dispatch: React.Dispatch<Action>;
  primeMemberSession: (member: Member) => void;
  primeAdminSession: (admin: StaffAdmin) => void;
}

const AppStoreContext = createContext<AppStoreValue | null>(null);

function nowStamp() {
  return new Date().toISOString().slice(0, 16).replace("T", " ");
}

function nextId(prefix: string) {
  return `${prefix}_${Date.now()}_${Math.random().toString(16).slice(2, 7)}`;
}

// SAFETY: product/order value is only a reference amount. Balance credit is commission only.
function getCommissionToCredit(order: Order) {
  const existingCommission = Number(order.commission ?? 0);
  if (existingCommission > 0) return existingCommission;
  return Math.round(Number(order.value ?? 0) * 0.2);
}

function hasCommissionAlreadyBeenCredited(order: Order) {
  return Boolean(order.commissionCreditedAt);
}

function createLocalOrderCode(orders: Order[]) {
  const existingCodes = new Set(orders.map((order) => order.referenceNumber || order.id));
  for (let attempt = 0; attempt < 10; attempt += 1) {
    const referenceNumber = generateOrderCode();
    if (!existingCodes.has(referenceNumber)) return referenceNumber;
  }
  return generateOrderCode();
}

function reducer(state: AppState, action: Action): AppState {
  if (action.type === "hydrate") return action.payload;

  if (action.type === "createTransaction") {
    const member = state.members.find((item) => item.username === action.payload.member) ?? state.members[0];
    if (!member) return state;
    const transaction: Transaction = {
      id: nextId("tx"),
      member: member.username,
      admin: member.referredBy,
      type: action.payload.type,
      amount: action.payload.amount,
      status: "pending",
      createdAt: nowStamp(),
    };
    return { ...state, transactions: [transaction, ...state.transactions] };
  }

  if (action.type === "updateTransaction") {
    const transaction = state.transactions.find((item) => item.id === action.payload.id);
    if (!transaction || transaction.status !== "pending") return state;

    const shouldApplyFinanceTotals = action.payload.status === "approved";
    const creditedAt = shouldApplyFinanceTotals ? nowStamp() : transaction.creditedAt ?? "";
    const withdrawalWasDeductedOnSubmit = transaction.type === "withdrawal" && Boolean(transaction.balanceDeductedAt);

    // SAFETY: withdrawals are deducted on submit. Approval should not deduct them again;
    // rejection refunds only if the pending withdrawal was already deducted.
    return {
      ...state,
      transactions: state.transactions.map((item) =>
        item.id === action.payload.id ? { ...item, status: action.payload.status, creditedAt } : item,
      ),
      admins: shouldApplyFinanceTotals
        ? state.admins.map((admin) => {
            if (admin.name !== transaction.admin) return admin;
            return transaction.type === "topup"
              ? {
                  ...admin,
                  todayDeposits: admin.todayDeposits + transaction.amount,
                  monthDeposits: admin.monthDeposits + transaction.amount,
                }
              : {
                  ...admin,
                  todayWithdrawals: admin.todayWithdrawals + transaction.amount,
                  monthWithdrawals: admin.monthWithdrawals + transaction.amount,
                };
          })
        : state.admins,
      members: state.members.map((member) => {
        if (member.username !== transaction.member) return member;

        if (action.payload.status === "approved") {
          if (transaction.type === "topup") return { ...member, balance: member.balance + transaction.amount };
          if (transaction.type === "withdrawal" && !withdrawalWasDeductedOnSubmit) {
            if (transaction.amount > member.balance) return member;
            return { ...member, balance: Math.max(0, member.balance - transaction.amount) };
          }
          return member;
        }

        if (action.payload.status === "rejected" && withdrawalWasDeductedOnSubmit) {
          return { ...member, balance: member.balance + transaction.amount };
        }

        return member;
      }),
    };
  }

  if (action.type === "addTransaction") {
    return { ...state, transactions: [action.payload, ...state.transactions] };
  }

  if (action.type === "createOrder") {
    const member = state.members.find((item) => item.username === action.payload.member);
    const product = action.payload.productId ? state.products.find((item) => item.id === action.payload.productId) : undefined;
    if (!member) return state;

    const order: Order = {
      id: nextId("ord"),
      referenceNumber: createLocalOrderCode(state.orders),
      memberId: member.id,
      member: member.username,
      admin: member.referredBy,
      productCode: product?.code,
      productName: product?.name,
      quantity: product ? 1 : 0,
      assignedProducts: product
        ? [
            {
              productId: product.id,
              code: product.code,
              name: product.name,
              price: product.price,
              commission: product.commission,
              quantity: 1,
              total: product.price,
            },
          ]
        : [],
      value: product?.price ?? 0,
      commission: product?.commission ?? 0,
      requiredBalance: product?.price ?? 0,
      status: product ? "product_assigned" : "waiting_assignment",
      createdAt: nowStamp(),
      assignedAt: product ? nowStamp() : undefined,
    };

    return {
      ...state,
      products: product ? state.products.map((item) => (item.id === product.id ? { ...item, quantity: Math.max(0, item.quantity - 1) } : item)) : state.products,
      orders: [order, ...state.orders],
    };
  }

  if (action.type === "completeOrder") {
    const order = state.orders.find((item) => item.id === action.payload.orderId);
    if (!order || !["assigned", "product_assigned", "belum_diserahkan"].includes(order.status)) return state;

    const completedAt = nowStamp();
    const commission = hasCommissionAlreadyBeenCredited(order) ? 0 : getCommissionToCredit(order);
    const commissionCreditedAt = hasCommissionAlreadyBeenCredited(order) ? order.commissionCreditedAt ?? "" : completedAt;

    return {
      ...state,
      orders: state.orders.map((item) =>
        item.id === order.id ? { ...item, status: "completed", completedAt, commissionCreditedAt } : item,
      ),
      members: state.members.map((member) =>
        member.id === order.memberId
          ? { ...member, balance: member.balance + commission, totalOrders: member.totalOrders + 1 }
          : member,
      ),
    };
  }

  if (action.type === "addOrder") {
    const order = action.payload;
    return {
      ...state,
      orders: [order, ...state.orders],
      products: state.products.map((product) =>
        order.status === "product_assigned" && product.code === order.productCode ? { ...product, quantity: Math.max(0, product.quantity - (order.quantity ?? 1)) } : product,
      ),
    };
  }

  if (action.type === "updateOrder") {
    const order = action.payload;
    const previousOrder = state.orders.find((item) => item.id === order.id);
    const newlyAssigned = ["waiting", "waiting_assignment"].includes(previousOrder?.status ?? "") && ["assigned", "product_assigned"].includes(order.status);
    return {
      ...state,
      orders: state.orders.map((item) => (item.id === order.id ? order : item)),
      products: newlyAssigned
        ? state.products.map((product) => {
            const assignedProduct = order.assignedProducts?.find((item) => item.productId === product.id || item.code === product.code);
            if (!assignedProduct) return product;
            return { ...product, quantity: Math.max(0, product.quantity - assignedProduct.quantity) };
          })
        : state.products,
    };
  }

  if (action.type === "replaceMemberOrders") {
    const mergedOrders = [
      ...state.orders.filter(
        (order) =>
          order.memberId !== action.payload.memberId,
      ),
      ...action.payload.orders,
    ];

    return {
      ...state,
      orders: mergedOrders.sort((left, right) => new Date(right.createdAt.replace(" ", "T")).getTime() - new Date(left.createdAt.replace(" ", "T")).getTime()),
    };
  }

  if (action.type === "completeOrderWithMember") {
    return {
      ...state,
      orders: state.orders.map((item) => (item.id === action.payload.order.id ? action.payload.order : item)),
      members: state.members.map((member) => (member.id === action.payload.member.id ? action.payload.member : member)),
    };
  }

  if (action.type === "updateMember") {
    return {
      ...state,
      members: state.members.some((member) => member.id === action.payload.id)
        ? state.members.map((member) => (member.id === action.payload.id ? action.payload : member))
        : [action.payload, ...state.members],
    };
  }

  if (action.type === "addProduct") return { ...state, products: [{ ...action.payload, id: action.payload.id ?? nextId("prod") }, ...state.products] };
  if (action.type === "updateProduct") return { ...state, products: state.products.map((product) => (product.id === action.payload.id ? action.payload : product)) };
  if (action.type === "deleteProduct") return { ...state, products: state.products.filter((product) => product.id !== action.payload.id) };
  if (action.type === "addBank") return { ...state, banks: [{ ...action.payload, id: action.payload.id ?? nextId("bank") }, ...state.banks] };
  if (action.type === "updateBank") return { ...state, banks: state.banks.map((bank) => (bank.id === action.payload.id ? action.payload : bank)) };
  if (action.type === "deleteBank") return { ...state, banks: state.banks.filter((bank) => bank.id !== action.payload.id) };
  if (action.type === "addAdmin") return { ...state, admins: [action.payload, ...state.admins] };
  if (action.type === "updateAdmin") {
    return {
      ...state,
      admins: state.admins.some((admin) => admin.id === action.payload.id)
        ? state.admins.map((admin) => (admin.id === action.payload.id ? action.payload : admin))
        : [action.payload, ...state.admins],
    };
  }
  if (action.type === "deleteAdmin") return { ...state, admins: state.admins.filter((admin) => admin.id !== action.payload.id) };
  if (action.type === "updateAccount") return { ...state, account: action.payload };

  return state;
}

export function AppStoreProvider({ children }: { children: React.ReactNode }) {
  const [state, dispatch] = useReducer(reducer, {
    ...initialState,
    admins: [],
    members: [],
    products: [],
    banks: [],
    transactions: [],
    orders: [],
  });
  const [ready, setReady] = useState(false);
  const [authenticatedMemberId, setAuthenticatedMemberId] = useState("");
  const primeMemberSession = useCallback((member: Member) => {
    dispatch({ type: "updateMember", payload: member });
    setAuthenticatedMemberId(member.id);
    setReady(true);
  }, []);
  const primeAdminSession = useCallback((admin: StaffAdmin) => {
    dispatch({ type: "updateAdmin", payload: admin });
    setAuthenticatedMemberId("");
    setReady(true);
  }, []);

  useEffect(() => {
    let mounted = true;
    let authSequence = 0;

    const reload = (authContext?: Awaited<ReturnType<typeof getAuthContext>>) => {
      return loadStoredState(authContext)
        .then((stored) => {
          if (!mounted) return;
          dispatch({ type: "hydrate", payload: stored });
          setReady(true);
        })
        .catch(() => {
          if (mounted) setReady(true);
        });
    };
    const unsubscribe = auth
      ? onAuthStateChanged(auth, async (user) => {
          const sequence = ++authSequence;
          if (!user) {
            setAuthenticatedMemberId("");
            await reload(null);
            return;
          }
          const context = await getAuthContext().catch(() => null);
          if (!mounted || sequence !== authSequence) return;
          setAuthenticatedMemberId(context?.role === "member" ? context.subjectId : "");
          await reload(context);
        })
      : undefined;
    if (!auth) reload();

    return () => {
      mounted = false;
      unsubscribe?.();
    };
  }, []);

  useEffect(() => {
    if (ready) saveLocalState(state);
  }, [ready, state]);

  useEffect(() => {
    if (!ready) return;
    const memberId = authenticatedMemberId;
    if (!memberId) return;

    return subscribeToMember(
      memberId,
      (member) => {
        if (member) dispatch({ type: "updateMember", payload: member });
      },
      (error) => console.warn("Unable to synchronize member record:", error),
    );
  }, [authenticatedMemberId, ready]);

  const value = useMemo(
    () => ({
      state,
      ready,
      persistence: firebaseReady ? ("firebase" as const) : ("local" as const),
      dispatch,
      primeMemberSession,
      primeAdminSession,
    }),
    [primeAdminSession, primeMemberSession, ready, state],
  );

  return <AppStoreContext.Provider value={value}>{children}</AppStoreContext.Provider>;
}

export function useAppStore() {
  const context = useContext(AppStoreContext);
  if (!context) throw new Error("useAppStore must be used inside AppStoreProvider");
  return context;
}
